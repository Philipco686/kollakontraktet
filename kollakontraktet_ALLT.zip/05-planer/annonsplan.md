# Kollakontraktet — annonsplan Meta/Instagram

Underlag till 12 kreativ i 8 olika mallar plus en karusell i fyra bilder.
Allt material ligger i `kollakontraktet_annonser.zip` (1080×1350 för flödet, 1080×1920 för stories).

---

## 1. Antaganden du måste bekräfta

Tre saker i materialet är mina gissningar. Ändra dem innan lansering.

| Vad | Vad jag skrivit | Varför det spelar roll |
|---|---|---|
| Pris | "Fast pris" i jämförelsemallen | Om du har freemium eller en gratis första analys är det en betydligt starkare rubrik |
| Riskexempel | Påhittade klausuler från ett fiktivt lokalhyresavtal | Riktiga fynd från en riktig analys höjer trovärdigheten mer än någon designdetalj |
| Varumärkesfärg | Bläckblått, markeringsgult, stämpelrött | Skicka hex-koder så renderar jag om allt |

---

## 2. Målgrupper

**A. Småföretagare (primär.)** Enskild firma och små AB som skriver lokalhyresavtal, leverantörsavtal och franchiseavtal. Har mest att förlora på en dålig klausul och lägst tröskel att betala. Intressen: Företagande, Verksamt.se, Bolagsverket, Driva eget, Fortnox, Visma.

**B. Privatpersoner i avtalsläge.** Andrahandskontrakt, anställningsavtal, bilköp, mäklaravtal. Stor volym, lägre betalningsvilja, kortare beslutsväg. Intressen: Blocket, Hemnet, Bostadsrätterna, Hyresgästföreningen, flyttrelaterade livshändelser.

**C. Frilansare och konsulter.** Uppdragsavtal, NDA, ramavtal. Läser avtal ofta, förstår värdet direkt. Intressen: Frilans Finans, Cool Company, Gigapay, LinkedIn-liknande beteenden.

Kör A och B i separata annonsuppsättningar. Deras klausuler och språk skiljer sig för mycket för att dela kreativ.

---

## 3. Trattstruktur

| Steg | Syfte | Kreativ | Budgetandel |
|---|---|---|---|
| Kall trafik | Stoppa scrollen, skapa oro | 01, 02, 07, karusellen | 60 % |
| Mellanled | Förklara mekaniken | 03, 04, 06, 08 | 25 % |
| Retargeting | Stänga affären | 05, karusellbild 4 | 15 % |

Retargetingpubliker: besökt sajten 30 dagar, sett 50 % av videon, engagerat sig med Instagram-kontot 90 dagar.

---

## 4. Kreativ och annonstext

### 01 — Sidan nio
**Mall:** helbild av avtalssidan, mörk toning nedtill. **Steg:** kall. **Målgrupp:** A + B.
- **Primärtext:** Ingen läser fjorton sidor avtalstext. Problemet är att den dyraste meningen sällan står på sidan ett. Kollakontraktet läser hela avtalet och markerar det som kan kosta dig pengar.
- **Rubrik:** Vad står på sidan nio i ditt avtal?
- **Beskrivning:** Avtalsanalys på svenska
- **CTA:** Läs mer

### 02 — 24 %
**Mall:** rent typografiskt på röd platta. **Steg:** kall. **Målgrupp:** A + C.
- **Primärtext:** Två procent per månad låter rimligt. Omräknat blir det 24 procent per år, mer än dubbelt mot vad som är marknadsmässigt. Sådana klausuler står i nästan varje leverantörsavtal.
- **Rubrik:** Räkna om dröjsmålsräntan i ditt avtal
- **CTA:** Läs mer

Den här är den mest scrollstoppande av alla tolv. Stor siffra, ingen bild, hög kontrast. Ge den egen budget.

### 03 — Jurist eller verktyg
**Mall:** jämförelse i två kolumner. **Steg:** mellanled. **Målgrupp:** A + C.
- **Primärtext:** En jurist läser avtalet åt dig på tre till fem dagar och tar timarvode. Kollakontraktet gör det på en minut till fast pris. Skillnaden är att juristen kan förhandla åt dig — allt annat kan vi.
- **Rubrik:** Två sätt att förstå ditt avtal
- **CTA:** Kom igång

Ärligheten i sista meningen är avsiktlig. Att erkänna vad verktyget inte gör höjer trovärdigheten i allt annat du påstår.

### 04 — Så funkar det
**Mall:** tre numrerade steg. **Steg:** mellanled. **Målgrupp:** alla.
- **Primärtext:** Ladda upp avtalet som PDF, Word eller ett foto av papperet. Vi läser varje sida och ger dig riskerna förklarade på svenska, med förslag på vad du bör förhandla om.
- **Rubrik:** Från avtal till svar på en minut
- **CTA:** Kom igång

### 05 — Notisen
**Mall:** mobilnotis mot mörk bakgrund. **Steg:** retargeting. **Målgrupp:** alla.
- **Primärtext:** Tre risker i ett fjortonsidigt hyresavtal. Automatisk förlängning, dröjsmålsränta på 24 procent per år och en indexklausul som bara går uppåt. Det tog en minut att hitta dem.
- **Rubrik:** 3 risker hittade
- **CTA:** Testa nu

Fungerar bra i stories eftersom den ser ut som en riktig notis snarare än en annons.

### 06 — Tre frågor
**Mall:** kryssrutor på vitt. **Steg:** mellanled. **Målgrupp:** A.
- **Primärtext:** Vet du vilket datum ditt avtal förlängs automatiskt? Vet du vad dröjsmålsräntan blir omräknat per år? Vet du vad det kostar att säga upp i förtid? Svarar du nej på någon av dem har du inte läst klart.
- **Rubrik:** Tre frågor om ditt avtal
- **CTA:** Läs mer

Frågeformatet driver kommentarer. Räkna med att svara på dem — organisk räckvidd på köpet.

### 07 — Rödpennan
**Mall:** avtal med handskrivna anteckningar. **Steg:** kall. **Målgrupp:** A + C.
- **Primärtext:** Så här ser ett avtal ut när någon som kan läsa det har gått igenom det. Ringar kring det som kostar pengar, en förklaring i marginalen och ett datum du behöver komma ihåg.
- **Rubrik:** Vi läser avtalet som en jurist gör
- **CTA:** Läs mer

Den handskrivna looken gör att den inte läses som en annons i första ögonkastet. Historiskt den typ av kreativ som får högst hook rate.

### 08 — Vilket avtal
**Mall:** rutnät med avtalstyper. **Steg:** mellanled. **Målgrupp:** bred prospektering.
- **Primärtext:** Hyresavtal, anställningsavtal, konsultavtal, andrahandskontrakt, leverantörsavtal, franchiseavtal. Ladda upp vilket svenskt avtal som helst och få riskerna förklarade på svenska.
- **Rubrik:** Vilket avtal ska du skriva på?
- **CTA:** Läs mer

Använd den här för att hitta vilket segment som faktiskt konverterar. Titta på vilken avtalstyp folk söker på efter klick.

### Karusell (4 bilder) — Fyra klausuler som kostar pengar
**Steg:** kall. **Målgrupp:** A.
- **Primärtext:** Fyra klausuler som står i nästan varje svenskt avtal, och vad de faktiskt betyder för din plånbok. Den sista är den som folk missar.
- **Rubrik per bild:** Förlängningen · Indexklausulen · Dröjsmålsräntan · Hur många står i ditt?
- **CTA:** Läs mer

Karuseller har högre kostnad per visning men betydligt längre uppehållstid. Bild 1 avgör allt — om den inte stoppar scrollen ser ingen bild 2.

---

## 5. Testplan

**Fas 1, vecka 1–2. Hitta vinnaren bland de kalla.**
Fyra annonsuppsättningar, en per kreativ: 01, 02, 07 och karusellen. Samma publik i alla, samma budget, ingen optimering under tiden. Mät enbart hook rate (3-sekundersvisningar delat med visningar) och kostnad per klick. Stäng inget före 1 000 visningar per uppsättning.

**Fas 2, vecka 3–4. Testa vinklarna mot vinnaren.**
Vinnaren från fas 1 möter 03, 06 och 08. Nu mäter du kostnad per uppladdat avtal, inte klick.

**Fas 3, löpande. Retargeting.**
05 och karusellbild 4 mot alla som besökt sajten men inte laddat upp något. Frekvenstak 3 per vecka.

---

## 6. Vad du faktiskt ska titta på

| Mätvärde | Vad det svarar på | Varningsflagga |
|---|---|---|
| Hook rate | Stoppar bilden scrollen? | Under 20 % — byt kreativ, inte text |
| Klickfrekvens | Är löftet tillräckligt intressant? | Under 1 % — problemet ligger i rubriken |
| Uppladdningar per klick | Håller landningssidan vad annonsen lovar? | Under 10 % — problemet ligger på sajten, inte i annonsen |
| Frekvens | Har publiken sett nog? | Över 3 — byt kreativ eller vidga publiken |

Den vanligaste felslutsatsen är att skylla på annonstexten när hook rate är låg. Är hook rate låg är det bilden som är fel. Är klickfrekvensen låg men hook rate hög är det rubriken.

---

## 7. Innan du trycker på start

1. Byt de påhittade riskexemplen mot tre riktiga fynd från en avtalsanalys du kört själv.
2. Bekräfta prisformuleringen i kreativ 03.
3. Skicka varumärkesfärger och logotyp så renderar jag om alla tolv.
4. Kontrollera att landningssidan upprepar samma formulering som annonsen. Klickar någon på "Vad står på sidan nio i ditt avtal?" ska den meningen finnas på sidan de landar på.
5. Sätt upp konvertering för uppladdat avtal, inte bara för sidbesök. Utan det mäter du fel sak i sex veckor.
