# Kollakontraktet — allt material

Det här paketet innehåller allt jag byggt: en film, 38 bilder och två planer. Börja här, resten hänger ihop med den här listan.

---

## Så här är mappen uppbyggd

```
01-film/           Reklamfilmen med voiceover
02-annonser/       8 annonser för betald marknadsföring (Meta)
03-flode/          11 bilder för Instagram-flödet
04-stories/        6 bilder för Instagram Stories
05-planer/         Två planer: en för betalt, en för organiskt
```

---

## 01 — Film

| Fil | Vad det är |
|---|---|
| `reklamfilm_20s.mp4` | 1080×1920, 20,3 sekunder, med svensk voiceover och ljuddesign. Fungerar som Reels, story och betald videoannons |
| `voiceover.wav` | Bara rösten, utan musik och effekter, om du vill mixa om |
| `animation_kalla.html` | Källfilen. Öppna i webbläsaren så spelas animationen upp i loop. Här ändrar du text och färger |

Rösten är syntetisk. Den duger för att testa, men en riktig inläsning låter bättre. Replikerna ligger på sekund 0,10 / 3,65 / 7,60 / 9,60 / 11,55 / 14,85 / 16,95 om du vill spela in egna.

---

## 02 — Annonser för betald marknadsföring

Åtta annonser i åtta olika mallar. Varje finns i två format: `_feed` (1080×1350, till flödet) och `_story` (1080×1920, till stories och Reels-placeringar).

| Fil | Vinkel | Använd till |
|---|---|---|
| `a1-sidan-nio` | Dold klausul, nyfikenhet | Kall trafik |
| `a2-24-procent` | Konkret kostnad, stor siffra | Kall trafik — testa den här först |
| `a3-jurist-vs` | Jämförelse mot alternativet | Mellanled |
| `a4-sa-funkar-det` | Tre steg, produktförklaring | Mellanled |
| `a5-notis` | Ser ut som en systemavisering | Retargeting |
| `a6-tre-fragor` | Frågeformat, driver kommentarer | Mellanled |
| `a7-rodpenna` | Handskrivna anteckningar på avtalet | Kall trafik — testa den här också |
| `a8-vilket-avtal` | Segmentering på avtalstyp | Bred prospektering |

Annonstext, rubrik och CTA för var och en finns i `05-planer/annonsplan.md`.

---

## 03 — Flödet

**Karusell A — fyra klausuler som kostar pengar** (4 bilder)
`klausul-1` till `klausul-4`. Ladda upp i nummerordning.

**Karusell B — ordlista** (6 bilder)
`ordlista-0` till `ordlista-5`. Bild 0 är omslaget, bild 5 är avslutet. Ladda upp i nummerordning.

**Enkelbilder**
`f-checklista` — byggd för att sparas och skärmdumpas.

---

## 04 — Stories

| Fil | Sticker att lägga på |
|---|---|
| `s1-omrostning` | Omröstning: Ja / Nej |
| `s2-quiz` | Quiz: 12 % / 24 % / 30 % — rätt svar är 24 % |
| `s3-lank` | Länksticker, placerad under den röda pilen |
| `s4-teaser` | Ingen |
| `s5-dm` | Ingen |
| `f-reelsomslag` | Omslagsbild till filmen. Motivet ligger i mitten så det inte beskärs i rutnätet |

Den tomma ytan i bilden är där stickern ska sitta. Lägger du den någon annanstans täcker den text.

---

## 05 — Planer

`instagramplan.md` — organiskt: vad som ska ligga i flödet, vad som ska ligga i stories, ordningen på de nio första inläggen, fyraveckorskalender, bildtexter och bioförslag.

`annonsplan.md` — betalt: annonstext för varje kreativ, tre målgruppssegment, trattstruktur och testplan i tre faser.

---

## Vad du gör härnäst, i ordning

1. **Bestäm ditt pris.** Jag har skrivit "Fast pris" i `a3-jurist-vs`. Har du en gratis första analys är det en betydligt starkare rubrik och då bygger jag om den bilden.
2. **Kör ett riktigt avtal genom verktyget.** Byt mina påhittade riskexempel mot tre autentiska fynd. Det höjer trovärdigheten mer än någon designändring.
3. **Skicka färgkoder och logotyp.** Bläckblått, gult och rött är mina gissningar. Med rätt hex-koder renderar jag om samtliga 38 bilder på en gång.
4. **Fixa bion och länken.** Peka direkt till uppladdningssidan, inte till startsidan.
5. **Publicera i den ordning som står i instagramplanen.** Ordlista-karusellen först, filmen som Reels sedan, checklistan tredje.
6. **Starta betalt först när flödet har innehåll.** Klickar någon på en annons och landar på ett tomt konto tappar du dem.

---

## Två saker jag vill vara tydlig med

Riskexemplen i materialet är påhittade av mig, byggda på ett fiktivt lokalhyresavtal. De är realistiska men de är inte dina. Publicerar du dem som de är påstår du något du inte kan belägga.

Voiceovern är maskinell. Jag har bearbetat den så långt det går, men jag kan inte höra resultatet — jag har mätt det. Lyssna igenom filen innan du kör den skarpt.
