# Kollakontraktet — Instagram-plan

## 1. Det som styr allt annat

Inlägg i flödet går inte att klicka på. Instagram tillåter ingen länk i bildtexten. Det betyder att varje format har en egen uppgift, och att mäta klick på ett flödesinlägg är att mäta fel sak.

| Format | Uppgift | Mäts på |
|---|---|---|
| Flödesinlägg | Räckvidd, trovärdighet, sparningar | Sparningar och delningar |
| Stories | Driva klick och samtal | Länktryck, svar på stickers |
| Reels | Nå folk som inte följer dig | Visningar från icke-följare |
| Betald annons | Klick i volym | Kostnad per uppladdat avtal |

Klickvägen är: **Reels och flöde bygger publik → stories konverterar den publiken → betalt skalar det som redan fungerar.**

Detta är också varför de nya kreativen ser ut som de gör. Omröstningen och quizet finns inte för att vara roliga, utan för att en person som svarat på en sticker får din nästa story högre upp i sitt flöde. Det är den storyn som har länken i sig.

---

## 2. Nytt material i den här leveransen

**Stories (1080×1920, med tomma stickerytor)**

| Fil | Vad den gör | Sticker att lägga på |
|---|---|---|
| `s1-omrostning` | Ställer en fråga folk inte kan svara på | Omröstning: Ja / Nej |
| `s2-quiz` | Testar dröjsmålsräntan | Quiz: 12 % / 24 % / 30 % |
| `s3-lank` | Den enda som ber om klicket | Länksticker, under pilen |
| `s4-teaser` | Skickar story-tittare till flödet | Ingen |
| `s5-dm` | Öppnar DM-konversationer | Ingen, uppmaningen räcker |

Stickerytan är medvetet tom i bilden. Lägger du stickern någon annanstans täcker den text.

**Flöde**

| Fil | Typ |
|---|---|
| `ordlista-0` till `ordlista-5` | Karusell i sex bilder: fyra juridiska ord översatta |
| `f-checklista` | Enkelbild byggd för att sparas och skärmdumpas |
| `f-reelsomslag` | Omslagsbild till videon, med motivet i mitten så det inte beskärs i rutnätet |

---

## 3. Ordningen i flödet

De nio första inläggen bestämmer vad en ny besökare tror att kontot är. Publicera i den här ordningen.

| Nr | Inlägg | Varför just här |
|---|---|---|
| 1 | Ordlista-karusellen | Ger värde innan den ber om något. Sparas mest av allt material |
| 2 | Reels: 20-sekundersfilmen | Räckvidd tidigt, medan kontot är litet |
| 3 | `f-checklista` | Andra sparbara inlägget. Två i rad etablerar vad kontot är till för |
| 4 | `a2-24-procent` | Första rena påståendet. Sticker ut i rutnätet mot de ljusa |
| 5 | Karusell A: fyra klausuler | Fördjupning för dem som stannat kvar |
| 6 | `a7-rodpenna` | Visar metoden. Först nu, när folk vet vem du är |
| 7 | `a4-sa-funkar-det` | Produktförklaring. Ingen bryr sig om den före inlägg sex |
| 8 | `a8-vilket-avtal` | Segmenterar publiken, driver kommentarer |
| 9 | `a3-jurist-vs` | Positionering mot alternativet. Sist, för att den är säljigast |

Efter de nio: tre inlägg i veckan, alltid i mönstret **värde → värde → produkt**. Bryter du det mönstret tappar du sparningar och därmed räckvidd.

---

## 4. Veckorytm i stories

Stories ska ligga varje vardag, tre till fem bilder i följd. En serie är alltid uppbyggd likadant:

**Bild 1 hakar. Bild 2 ger något. Bild 3 har länken.**

Länken ligger aldrig på första bilden. Sjuttio procent av tittarna svepvidare innan bild tre om bild ett inte håller, och de som svarat på en sticker i bild ett är just de som kommer att se bild tre.

| Dag | Serie |
|---|---|
| Måndag | `s1-omrostning` → svarsbild med facit → `s3-lank` |
| Tisdag | Dela veckans flödesinlägg till story med en egen kommentar |
| Onsdag | `s2-quiz` → facit: 24 % → `s3-lank` |
| Torsdag | `s4-teaser` inför torsdagens flödesinlägg |
| Fredag | `s5-dm` |

Facitbilderna gör du enklast i Instagrams egen editor: skärmdump av föregående story plus en textrad. De ska se lite ofärdiga ut — det är hela poängen med stories.

**Utvalda stories att spara högst upp på profilen:** Ordlista, Så funkar det, Riskexempel.

---

## 5. Fyra veckor

| Vecka | Måndag | Onsdag | Fredag | Stories |
|---|---|---|---|---|
| 1 | Ordlista-karusellen | Reels: filmen | `f-checklista` | Enligt rytmen ovan |
| 2 | `a2-24-procent` | Karusell A | `a7-rodpenna` | Samma, plus DM-utskick på fredag |
| 3 | `a4-sa-funkar-det` | Reels: klipp om ur filmen | `a8-vilket-avtal` | Lägg till en story med ett riktigt kundfall |
| 4 | `a3-jurist-vs` | Ordlista del 2 (nya ord) | `a6-tre-fragor` | Utvärdera och gör om det som fungerat |

Efter vecka fyra: sluta producera nytt och gör om det som gick bäst i ett nytt format i stället. Ett inlägg som fungerar i karusell fungerar nästan alltid som Reels.

---

## 6. Bildtexter

**Ordlista-karusellen**
> Fyra ord som står i nästan varje svenskt avtal, och vad de faktiskt betyder när du läser dem långsamt.
>
> Vite. Indexklausul. Konkurrensklausul. Dröjsmålsränta.
>
> Den sista är den som kostar mest, eftersom den nästan alltid anges per månad. Två procent låter rimligt tills du gångrar med tolv.
>
> Spara inlägget till nästa gång du ska skriva på något.

**Checklistan**
> Fyra saker att gå igenom innan du skriver under. Tar tio minuter och sparar dig från det vanligaste misstaget: att upptäcka förlängningsklausulen nio månader för sent.

**24 %**
> Dröjsmålsränta anges nästan alltid per månad. Det är inte en slump. Två procent per månad blir tjugofyra procent per år, mer än dubbelt mot vad som är marknadsmässigt. Kolla ditt eget avtal.

Skriv aldrig "länk i bio" i varje bildtext. Gör det i vart tredje inlägg. Ett konto som ber om något i varje inlägg tappar räckvidd.

---

## 7. Bion

Bion är den enda permanenta länken du har. Den ska svara på tre saker inom två rader.

> Vi läser hela avtalet åt dig och förklarar riskerna på svenska.
> Hyresavtal, anställningsavtal, leverantörsavtal.
> ↓ Ladda upp ditt avtal

Peka länken direkt till uppladdningssidan, inte till startsidan. Varje extra klick tappar ungefär hälften.

---

## 8. Vad du ska titta på efter fyra veckor

| Mätvärde | Var | Vad det betyder |
|---|---|---|
| Sparningar per inlägg | Flöde | Det enda som driver räckvidd åt dig gratis |
| Genomförandegrad | Stories | Under 60 % till sista bilden: första bilden är för svag |
| Länktryck | Stories | Det här är ditt egentliga trafikmått |
| DM-svar | Stories | Varje svar öppnar en kanal du får använda igen |
| Visningar från icke-följare | Reels | Under 50 %: du pratar bara med folk du redan har |

Den vanligaste nybörjarmissen är att titta på följare. Följarantalet betyder ingenting för en tjänst som din. Trettio personer som laddat upp ett avtal är värda mer än tretusen följare.

---

## 9. Kvar att göra

1. Byt de påhittade riskexemplen mot riktiga fynd från en egen analys.
2. Skicka varumärkesfärger och logotyp så renderar jag om samtliga trettio bilder.
3. Bestäm vad DM-checklistan faktiskt innehåller innan du publicerar `s5-dm`. Utlovat material som inte finns är det snabbaste sättet att bränna förtroende.
4. Sätt upp en spårningslänk per kanal så du kan skilja story-trafik från betald trafik.


---

## 10. Läsbarhetsregler (gäller allt material från och med nu)

En flödesbild på 1080 px visas ungefär 390 punkter bred på en telefon, alltså en tredjedel. Det ger den här omräkningen, och den är anledningen till att materialet är ombyggt.

| I filen (1080 px bred) | På telefonen | Duger det? |
|---|---|---|
| 28 px | 10 pt | Nej |
| 34 px | 12 pt | Nej |
| 44 px | 16 pt | Ja, minimum för brödtext |
| 80 px | 29 pt | Rubrik |

Reglerna materialet nu följer:

1. Brödtext aldrig under 44 px. Etiketter aldrig under 36 px.
2. Inga texter satta med opacity. Alla textfärger är solida och mätta: bläck på papper ger 15,2:1, brödtextgrå på vitt 8,9:1, vit på rött 5,9:1.
3. Ljus botten på sju av åtta annonser. Kvar i mörkt är bara story-teasern, som behöver kontrasten mot resten av serien.
4. Knapp med pil på varje betald annons. Meta ritar sin egen knapp under bilden, men en synlig knapp i bilden höjer klickfrekvensen ändå, eftersom ögat söker efter något klickbart innan det läser.
5. Högst tjugo ord per bild. Större text ger mindre plats, och det är avsikten.
